# Get the directory where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "Current script directory: $ScriptDir" -ForegroundColor Cyan
Write-Host ""

# Check if the directory is already in PATH
$currentPath = [Environment]::GetEnvironmentVariable("Path", "Machine")
if ($currentPath -like "*$ScriptDir*") {
    Write-Host "Directory is already in system PATH!" -ForegroundColor Green
    Write-Host ""
    goto after_path
}

$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -like "*$ScriptDir*") {
    Write-Host "Directory is already in user PATH!" -ForegroundColor Green
    Write-Host ""
    goto after_path
}

# Add to PATH for current session
$env:PATH = "$env:PATH;$ScriptDir"
Write-Host "Added to PATH for current session." -ForegroundColor Green

# Ask user if they want to add permanently
Write-Host ""
$choice = Read-Host "Do you want to add this directory to PATH permanently? (Y/N)"

if ($choice.ToUpper() -ne "Y") {
    goto after_path
}

# Try to add to system PATH permanently (requires admin rights)
Write-Host "Adding to system PATH permanently..." -ForegroundColor Yellow

try {
    $currentSystemPath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    
    if ([string]::IsNullOrEmpty($currentSystemPath)) {
        $newSystemPath = $ScriptDir
    } else {
        $newSystemPath = "$currentSystemPath;$ScriptDir"
    }
    
    [Environment]::SetEnvironmentVariable("Path", $newSystemPath, "Machine")
    Write-Host "Successfully added to system PATH!" -ForegroundColor Green
    Write-Host "Please restart your command prompt or applications to see the changes." -ForegroundColor Yellow
    
    # Broadcast environment change
    $HWND_BROADCAST = [IntPtr] 0xffff
    $WM_SETTINGCHANGE = 0x1a
    $result = [Win32.Environment]::SendMessageTimeout($HWND_BROADCAST, $WM_SETTINGCHANGE, [IntPtr]::Zero, "Environment", 2, 5000, [ref] $null)
} catch {
    Write-Host "Failed to add to system PATH. Trying user PATH instead..." -ForegroundColor Yellow
    
    try {
        $currentUserPath = [Environment]::GetEnvironmentVariable("Path", "User")
        
        # Check if user PATH already contains our directory
        if (![string]::IsNullOrEmpty($currentUserPath) -and $currentUserPath -like "*$ScriptDir*") {
            Write-Host "Directory is already in user PATH!" -ForegroundColor Green
            goto after_path
        }
        
        if ([string]::IsNullOrEmpty($currentUserPath)) {
            $newUserPath = $ScriptDir
        } else {
            $newUserPath = "$currentUserPath;$ScriptDir"
        }
        
        [Environment]::SetEnvironmentVariable("Path", $newUserPath, "User")
        Write-Host "Successfully added to user PATH!" -ForegroundColor Green
        Write-Host "Please restart your command prompt or applications to see the changes." -ForegroundColor Yellow
    } catch {
        Write-Host "Failed to add to PATH permanently. You may need to run as administrator." -ForegroundColor Red
    }
}

:after_path
Write-Host ""
Write-Host "Installing Python package 'rich'..." -ForegroundColor Cyan

try {
    $pipResult = & pip3 install rich 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Successfully installed 'rich'!" -ForegroundColor Green
    } else {
        Write-Host "Failed to install 'rich'. Error: $pipResult" -ForegroundColor Red
        Write-Host "Make sure Python and pip3 are installed." -ForegroundColor Yellow
    }
} catch {
    Write-Host "Failed to install 'rich'. Make sure Python and pip3 are installed." -ForegroundColor Red
    Write-Host "Error: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "Press any key to continue..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")