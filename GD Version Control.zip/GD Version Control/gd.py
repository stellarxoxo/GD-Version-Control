import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from sys import argv
import sqlite3
import time
import ws
import json
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.text import Text
from rich import print as rprint

console = Console()
websocket = ws.GDWebSocket()

conn = sqlite3.connect('database.db')
c = conn.cursor()

current_level = None

def list_levels():
    console.print(Panel.fit("Available Levels", style="bold yellow"))
    c.execute('SELECT rowid, name, timeCreated, commits FROM levels')
    levels = c.fetchall()
    
    if not levels:
        console.print("[yellow]No levels found.[/yellow]")
        return
    
    table = Table()
    table.add_column("ID", style="bold blue", justify="center")
    table.add_column("Name", style="cyan")
    table.add_column("Created", style="magenta")
    table.add_column("Commits", style="green", justify="center")
    
    for rowid, name, timeCreated, commits in levels:
        table.add_row(str(rowid), name, time.ctime(timeCreated), str(commits))
    
    console.print(table)

def create(name):
    console.print(f"[green]Creating level:[/green] [bold]{name}[/bold]")
    
    c.execute('INSERT INTO levels  (timeCreated, name, commits) VALUES (?, ?, ?)', (int(time.time()), name, 0))
    conn.commit()

    os.makedirs(f'levels/{name.replace(" ", "_")}', exist_ok=True)
    console.print(f"[bold green]Level '{name}' created successfully![/bold green]")

def delete(name):
    if not Confirm.ask(f"[red]Are you sure you want to delete the level '{name}'?[/red]\n[yellow]This action cannot be undone.[/yellow]"):
        console.print("[yellow]Deletion cancelled.[/yellow]")
        return
    
    c.execute('DELETE FROM levels WHERE name = ?', (name,))
    conn.commit()
    os.rmdir(f'levels/{name.replace(" ", "_")}')
    console.print(f"[bold red]Level '{name}' deleted successfully.[/bold red]")

def sanitize_filename(name):
    return "".join(c for c in name if c.isalnum() or c in (' ', '_', '-')).rstrip().strip()

def commit():
    console.print(Panel.fit("Starting Commit Process", style="bold yellow"))
    
    if websocket.connected == True:
        websocket.disconnect()
    websocket.connect()

    global current_level
    if current_level is None:
        list_levels()
        choice = Prompt.ask("\n[cyan]Enter level [ID or Name] to commit to[/cyan]")
        if choice.isdigit():
            c.execute('SELECT * FROM levels WHERE rowid = ?', (choice,))
        else:
            c.execute('SELECT * FROM levels WHERE name = ?', (choice,))
        level = c.fetchone()
        if not level:
            console.print("[red]Level not found.[/red]")
            return
        current_level = level

    console.print("[yellow]Fetching level data from Geometry Dash...[/yellow]")
    response = str(websocket.get_level_string())

    if response == "-1":
        console.print("[red]Failed to get level data.[/red]")
        console.print("[yellow]You need to be in the level editor.[/yellow]")
        return
    
    response = json.loads(response)

    if response["status"] != "successful":
        console.print("[red]Failed to fetch level string from WebSocket.[/red]")
        console.print(f"[red]Error:[/red] {response}")
        return
    
    console.print("[green]Level data fetched successfully![/green]")
    level_string = response["response"]

    del response # it can be big and its not needed anymore

    compressed_level = level_string

    commit_title = Prompt.ask("[cyan]Enter commit title[/cyan]")
    commit_message = Prompt.ask("[cyan]Enter commit message[/cyan]")

    console.print("[yellow]Processing commit data...[/yellow]")

    header = f"<?xml version=\"1.0\"?><plist version=\"1.0\" gjver=\"2.0\"><dict><k>kCEK</k><i>4</i><k>k18</k><i>1</i><k>k36</k><i>5</i><k>k23</k><i>5</i><k>k2</k><s>{commit_title}</s><k>k4</k><s>"
    footer = "</s><k>k5</k><s>femboy</s><k>k101</k><s>0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0</s><k>k11</k><i>21630</i><k>k13</k><t /><k>k21</k><i>2</i><k>k16</k><i>1</i><k>k80</k><i>1586</i><k>k27</k><i>21630</i><k>k50</k><i>45</i><k>k47</k><t /><k>k48</k><i>112</i><k>kI1</k><r>198.257</r><k>kI2</k><r>82.6258</r><k>kI3</k><r>0.502578</r><k>kI5</k><i>12</i><k>kI7</k><i>-1</i><k>kI6</k><d><k>0</k><s>0</s><k>1</k><s>0</s><k>2</k><s>0</s><k>3</k><s>0</s><k>4</k><s>0</s><k>5</k><s>0</s><k>6</k><s>0</s><k>7</k><s>0</s><k>8</k><s>0</s><k>9</k><s>0</s><k>10</k><s>0</s><k>11</k><s>0</s><k>12</k><s>0</s><k>13</k><s>0</s><k>14</k><s>0</s></d></dict></plist>"
    full_commit_data = header + compressed_level + footer

    # get current commits and increment by 1
    console.print(f"[cyan]Current level:[/cyan] [bold]{current_level[1]}[/bold]")
    c.execute('SELECT commits FROM levels WHERE name = ?', (current_level[1],))
    commits = c.fetchone()[0] + 1
    c.execute('UPDATE levels SET commits = ? WHERE name = ?', (commits, current_level[1]))
    conn.commit()
        
    # create new commit in commit table
    c.execute('INSERT INTO commits (time, name, description, id) VALUES (?, ?, ?, ?)', (int(time.time()), commit_title, commit_message, commits))
    conn.commit()

    console.print(f"[cyan]Sanitized filename:[/cyan] {sanitize_filename(commit_title)}")
    
    filename = f'levels/{current_level[1].replace(" ", "_")}/{commits} - {sanitize_filename(commit_title)}.stlr'
    with open(filename, 'w', encoding='utf-8') as f:
        object_split = full_commit_data.split(';')
        # remove the first and last elements of the list
        object_split = object_split[1:-1]
        f.write(';'.join(object_split))
    
    console.print(Panel(
        f"[bold green]Commit Successful![/bold green]\n\n"
        f"[cyan]Level:[/cyan] [bold]{current_level[1]}[/bold]\n"
        f"[cyan]Commit ID:[/cyan] [bold]#{commits}[/bold]\n"
        f"[cyan]Title:[/cyan] [bold]{commit_title}[/bold]\n"
        f"[cyan]Message:[/cyan] {commit_message}",
        style="green"
    ))

def get_commits():
    console.print(Panel.fit("Restore Commit", style="bold blue"))
    
    list_levels()
    choice = Prompt.ask("\n[cyan]Enter level [ID or Name] to commit to[/cyan]")
    if choice.isdigit():
        c.execute('SELECT * FROM levels WHERE rowid = ?', (choice,))
    else:
        c.execute('SELECT * FROM levels WHERE name = ?', (choice,))
    level = c.fetchone()
    level_name = level[1] if level else None
    if not level:
        console.print("[red]Level not found.[/red]")
        return
    
    # now go to that folder 
    folder_path = f'levels/{level_name.replace(" ", "_")}'
    if not os.path.exists(folder_path):
        console.print("[yellow]No commits found for this level.[/yellow]")
        return
    
    commits = [f for f in os.listdir(folder_path) if f.endswith('.stlr')]
    if not commits:
        console.print("[yellow]No commits found for this level.[/yellow]")
        return

    console.print(f"\n[bold]Commits for level '{level_name}':[/bold]")
    
    table = Table()
    table.add_column("ID", style="cyan", justify="center")
    table.add_column("Title", style="magenta")
    
    commit_ids = []
    for commit in commits:
        commit_id = int(commit.split(' - ')[0].strip())
        commit_title = commit.split(' - ')[1].replace('.stlr', '')
        commit_ids.append({"filename": commit, "id": commit_id})
        table.add_row(str(commit_id), commit_title)
    
    console.print(table)
    
    selected_id = Prompt.ask("\n[cyan]Enter commit ID to restore[/cyan]")

    selected_commit = None
    for commit in commit_ids:
        if commit["id"] == int(selected_id):
            selected_commit = commit
            break
    
    if not selected_commit:
        console.print("[red]Invalid commit ID.[/red]")
        return

    with open(f'{folder_path}/{selected_commit["filename"]}', 'r', encoding='utf-8') as f:
        commit_data = f.read().strip() + ";"

    console.print(Panel(
        "[yellow]IMPORTANT INSTRUCTIONS:[/yellow]\n\n"
        "1. Create a new level in Geometry Dash\n"
        "2. Open the level editor\n"
        "3. Press Enter here to restore the commit\n\n"
        "[red]WARNING: This will overwrite your current level in the editor.[/red]\n"
        "[red]Make sure to back up any unsaved work![/red]",
        style="yellow"
    ))
    
    Prompt.ask("[cyan]Press Enter when ready[/cyan]", default="")

    console.print("[yellow]Connecting to Geometry Dash...[/yellow]")
    if websocket.connected == True:
        websocket.disconnect()
    websocket.connect()

    console.print("[yellow]Restoring commit...[/yellow]")
    websocket.send_message(
        {
            "action": "ADD_OBJECTS",
            "objects": commit_data
        }
    )
    console.print("[bold green]Commit restored successfully![/bold green]")

def purge():
    # big warning to confirm
    console.print(Panel.fit("[bold red]WARNING: This will delete ALL levels and commits, and clear the database![/bold red]", style="red"))
    if not Confirm.ask("[red]Are you absolutely sure you want to proceed? This action cannot be undone.[/red]"):
        console.print("[yellow]Purge cancelled.[/yellow]")
        return
    c.execute('DELETE FROM levels')
    c.execute('DELETE FROM commits')
    conn.commit()

    # delete folder "levels" and all its contents (and all subfolders)
    import shutil
    if os.path.exists('levels'):
        shutil.rmtree('levels')
    console.print("[bold red]All levels and commits have been deleted, and the database has been cleared.[/bold red]")

if __name__ == "__main__":
    if len(argv) > 1:

        if argv[1] == "create":
            name = Prompt.ask("[cyan]Enter level name[/cyan]")
            create(name)
            
        elif argv[1] == "list":
            console.print(Panel.fit("Listing All Levels", style="bold cyan"))
            list_levels()
        
        elif argv[1] == "delete" or argv[1] == "destroy":
            console.print(Panel.fit("Delete Level", style="bold red"))
            list_levels()
            name = Prompt.ask("\n[red]Enter level name to delete[/red]")
            delete(name)

        elif argv[1] == "commit":
            commit()
        elif argv[1] == "get":
            get_commits()
        elif argv[1] == "purge":
            purge()
    else:
        console.print(Panel(
            "[bold cyan]GD Version Control System[/bold cyan]\n\n"
            "[yellow]Usage:[/yellow] [bold]gd [command][/bold]\n\n"
            "[yellow]Commands:[/yellow]\n"
            "  [cyan]create[/cyan]   Create a new level\n"
            "  [cyan]list[/cyan]     List all levels\n"
            "  [cyan]delete[/cyan]   Delete a level\n"
            "  [cyan]commit[/cyan]   Commit changes to a level\n"
            "  [cyan]get[/cyan]      Restore commits back into Geometry Dash\n"
            "  [cyan]purge[/cyan]    Delete all levels and commits. Also clears the database",
            title="Help",
            style="blue"
        ))