import websocket
import json
import threading
import time
import queue

class GDWebSocket:
    def __init__(self, url="ws://127.0.0.1:1313"):
        self.url = url
        self.ws = None
        self.connected = False
        self.response_queue = queue.Queue()
        
    def connect(self):
        """Connect to the WebSocket server"""
        # Close existing connection if any
        if self.ws:
            try:
                self.ws.close()
            except:
                pass
        
        self.connected = False
        
        def on_message(ws, message):
            # Put received message in queue for retrieval
            self.response_queue.put(message)
        
        def on_close(ws, close_status_code, close_msg):
            self.connected = False
        
        def on_open(ws):
            self.connected = True
        
        def on_error(ws, error):
            print("Failed to get level data. You need to be the level editor.")
            print("prepare for a crash")
            self.connected = False
        
        self.ws = websocket.WebSocketApp(self.url,
                                       on_open=on_open,
                                       on_message=on_message,
                                       on_close=on_close,
                                       on_error=on_error)
        
        
        # Run WebSocket in a separate thread
        def run_ws():
            self.ws.run_forever()
        
        ws_thread = threading.Thread(target=run_ws)
        ws_thread.daemon = True
        ws_thread.start()
        
        # Wait for connection to establish
        timeout = 5
        start_time = time.time()
        while not self.connected and (time.time() - start_time) < timeout:
            time.sleep(0.1)
        
        if not self.connected:
            raise ConnectionError("Failed to connect to WebSocket server")
        
        return self
    
    def send_message(self, data, retry=True):
        """Send a message through the WebSocket with auto-reconnect"""
        if not self.connected or not self.ws:
            if retry:
                print("WebSocket not connected. Attempting to reconnect...")
                try:
                    self.connect()
                    return self.send_message(data, retry=False)
                except Exception as e:
                    raise ConnectionError(f"Failed to reconnect and send message: {e}")
            else:
                raise ConnectionError("Not connected to WebSocket server")
        
        try:
            self.ws.send(json.dumps(data))
        except Exception as e:
            if retry:
                try:
                    self.connected = False
                    self.connect()
                    return self.send_message(data, retry=False)
                except Exception as reconnect_error:
                    raise ConnectionError(f"Failed to reconnect and send message: {reconnect_error}")
            else:
                raise
    
    def get_level_string(self, timeout=10):
        """Send GET_LEVEL_STRING request and return the response"""
        # Clear any existing messages in queue
        while not self.response_queue.empty():
            try:
                self.response_queue.get_nowait()
            except queue.Empty:
                break
        
        # Send the request
        message = {
            "action": "GET_LEVEL_STRING"
        }
        self.send_message(message)
        
        # Wait for response
        try:
            response = self.response_queue.get(timeout=timeout)
            return response
        except:
            return -1
    
    def disconnect(self):
        """Close the WebSocket connection"""
        if self.ws:
            self.ws.close()
        self.connected = False